from django.urls import path,include
from . import views


urlpatterns = [
   path('festival/',views.festival1,name='festival1'),
]