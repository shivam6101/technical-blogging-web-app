from django.shortcuts import render,redirect


def festival1(request):
    return render(request,'festival/festival1.html')
