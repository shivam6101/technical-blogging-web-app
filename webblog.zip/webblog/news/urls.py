from django.urls import path,include
from . import views


urlpatterns = [
   path('news1/',views.news1,name='news1'),
]