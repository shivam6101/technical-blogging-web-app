from django.shortcuts import render,redirect

def news1(request):
    return render(request,'news/news1.html')