from django.shortcuts import render,redirect

def sports1(request):
    return render(request,'sports/sports1.html')