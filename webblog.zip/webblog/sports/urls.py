from django.urls import path,include
from . import views


urlpatterns = [
   path('sports1/',views.sports1,name='sports1'),
]