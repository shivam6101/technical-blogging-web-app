from django.shortcuts import render,redirect

def reviews(request):
    return render(request,'reviews/review1.html')
def redminote9(request):
    return render(request,'reviews/redmi-note-9-price-in-india.html')
def iphone11(request):
    return render(request,'reviews/iphone11.html')
def mobiles(request):
    return render(request,'reviews/mobiles.html')