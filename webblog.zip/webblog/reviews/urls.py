from django.urls import path,include
from . import views


urlpatterns = [
   path('reviews/',views.reviews,name='reviews'),
   path('redminote9/',views.redminote9,name='redminote9'),
   path('iphone11/',views.iphone11,name='iphone11'),
   path('mobiles/',views.mobiles,name='mobiles'),
]