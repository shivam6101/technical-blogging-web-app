from django.urls import path,include
from . import views


urlpatterns = [
   path('technology1/',views.technology1,name='technology1'),
   path('iot/',views.iot,name='iot'),
   path('ai/',views.ai,name='ai'),
   path('hacker/',views.hacker,name='hacker'),
]