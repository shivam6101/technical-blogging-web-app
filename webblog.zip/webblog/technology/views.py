from django.shortcuts import render,redirect


def technology1(request):
    return render(request,'technology/technology1.html')
def iot(request):
    return render(request,'technology/iot.html')
def ai(request):
    return render(request,'technology/ai.html')
def hacker(request):
    return render(request,'technology/hacker.html')
