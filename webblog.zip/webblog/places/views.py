from django.shortcuts import render,redirect

def earn(request):
    return render(request,'places/earn.html')

def earn_online(request):
    return render(request,'places/earn_online.html')