from django.urls import path,include
from . import views


urlpatterns = [
   path('earn/',views.earn,name='earn'),
   path('earn_online/',views.earn_online,name='earn_online'),
]